import React, { useEffect, useState } from "react";
import axios from "axios";
import defaultImage from "../../../assets/images/product.png";
import "./AllCategories.css";
import { useNavigate } from "react-router-dom";

const AllCategories = () => {
  const [categoriesWithSubcategories, setCategoriesWithSubcategories] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const navigate = useNavigate();

  useEffect(() => {
    const fetchCategoriesAndSubcategories = async () => {
      try {
        const categoryRes = await axios.post("http://127.0.0.1:8000/get-all-category-subcategory", {
          // customer_id: null, // Pass customer_id if needed
          customer_id: localStorage.getItem("customer_id") || null 
        });

        if (categoryRes.data.status_code === 200) {
          setCategoriesWithSubcategories(categoryRes.data.categories);
        } else {
          setError("Failed to load categories");
        }
      } catch (err) {
        console.error("Failed to fetch categories and subcategories", err);
        setError("An error occurred while fetching data.");
      } finally {
        setLoading(false);
      }
    };

    fetchCategoriesAndSubcategories();
  }, []);

  if (loading) {
    return <div>Loading...</div>;
  }

  if (error) {
    return <div>{error}</div>;
  }

  const handleSubcategoryClick = (categoryName, subCategoryName) => {
    const selectedCategory = categoriesWithSubcategories.find(cat => cat.category_name === categoryName);
    navigate("/all-products", {
      state: {
        selectedCategory,
        selectedSubcategory: subCategoryName,
      },
    });
  };
  
  

  return (
    <div className="all-categories-section">
      {categoriesWithSubcategories.length > 0 ? (
        categoriesWithSubcategories
          .filter((cat) => cat.sub_categoryies && cat.sub_categoryies.length > 0) // Filter out categories with no subcategories
          .map((cat) => (
            <div key={cat.category_id} className="all-categories">
              <h2 className="all-categories-heading">{cat.category_name}</h2>
              <div className="all-categories-subcategories">
                {cat.sub_categoryies.map((sub) => (
                  <div key={sub.id} className="all-categories-content" 
                  onClick={() => handleSubcategoryClick(cat.category_name, sub.sub_category_name)}
>
                    <img
                      className="all-categories-image"
                      src={sub.sub_category_image || defaultImage}
                      alt={sub.sub_category_name}
                      onError={(e) => e.target.src = defaultImage}
                    />
                    <p className="all-categories-name">{sub.sub_category_name}</p>
                  </div>
                ))}
              </div>
            </div>
          ))
      ) : (
        <div>No categories with subcategories available.</div>
      )}
    </div>
  );
};

export default AllCategories;
