// MobileHeader.jsx
import React from "react";
import { BiCategory } from "react-icons/bi";
import { FaSearch, FaUser, FaClipboardList, FaMapMarkerAlt, FaSignOutAlt, FaSignInAlt, FaHome, FaShoppingCart, FaPhone } from "react-icons/fa";
import { IoMdPerson } from "react-icons/io";
import { FiChevronRight } from "react-icons/fi";
import { useNavigate } from "react-router-dom";
import Logo from "../../../assets/images/logo.png";
import { useState } from "react";

const MobileHeader = ({
    handleLogout,
    cartCount,

}) => {
    const navigate = useNavigate();
    const [isUserDropdownOpen, setIsUserDropdownOpen] = React.useState(false);
    const toggleUserDropdown = () => {
        setIsUserDropdownOpen(!isUserDropdownOpen);
    };
    const customerId = localStorage.getItem("customer_id");

    const isValidCustomerId = !(
        customerId === null ||
        customerId === "null" ||
        customerId === "undefined" ||
        customerId === ""
    );
    const shouldShowLoginSignup = !isValidCustomerId;

    const handleAllCategories =()=>{
        navigate("/all-categories")
    }

    return (
        <>
            <div className="mobile-header-section">
                <div className="mobile-header">
                    <div className="mobile-customer-logo" onClick={() => navigate("/")}>
                        <img src={Logo} alt="Logo" />
                    </div>
                    <div className="mobile-search-icon">
                        <input
                            className="mobile-search-icon-input"
                            type="text"
                            placeholder="Search"
                        />
                        <FaSearch className="mobile-customer-search-icon" />
                    </div>
                    <div className="mobile-menu">
                        <div className="user-icon-wrapper" onClick={toggleUserDropdown}>
                            <IoMdPerson size={24} />
                            {isUserDropdownOpen && (
                                <div className="customer-dropdown-menu mobile-user-dropdown">
                                    <ul>
                                        {shouldShowLoginSignup ? (
                                            <li onClick={() => navigate("/customer-login")}><FaSignInAlt /> Login / SignUp</li>
                                        ) : (
                                            <>
                                                <li onClick={() => navigate("/profile")}><FaUser /> My Profile</li>
                                                <li onClick={() => navigate("/my-orders")}><FaClipboardList /> My Orders</li>
                                                <li onClick={() => navigate("/address")}><FaMapMarkerAlt /> Address</li>
                                                <li onClick={handleLogout}><FaSignOutAlt /> Logout</li>
                                            </>
                                        )}
                                    </ul>
                                </div>
                            )}
                        </div>
                    </div>

                </div>
            </div>




            {/* Bottom Navigation */}
            <div className="mobile-nav-icon-wrapper">
                <div className="nav-item" onClick={() => navigate("/")}>
                    <FaHome className="nav-icon" />
                    <span>Home</span>
                </div>
                <div className="nav-item" onClick={() => handleAllCategories()} >
                    <BiCategory className="nav-icon" />
                    <span>Categories</span>
                </div>
                <div className="nav-item cart-icon" onClick={() => navigate("/view-cart-products")}>
                    <FaShoppingCart className="nav-icon" />
                    {cartCount > 0 && <span className="customer-cart-badge">{cartCount}</span>}

                    <span>Cart</span>
                </div>
                <div className="nav-item" onClick={() => navigate("/contact")}>
                    <FaPhone className="nav-icon" />
                    <span>Contact</span>
                </div>
            </div>

        </>
    );
};

export default MobileHeader;
