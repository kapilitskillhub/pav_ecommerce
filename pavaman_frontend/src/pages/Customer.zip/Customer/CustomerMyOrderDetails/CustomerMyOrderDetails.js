import React, { useEffect, useState } from 'react';
import './CustomerMyOrderDetails.css';
import { useLocation } from 'react-router-dom';

const CustomerMyOrderDetails = () => {
  const [orderDetails, setOrderDetails] = useState([]);
  const location = useLocation();
  const { payments,order} = location.state || {};
  const [loading, setLoading] = useState(true);
  const customerId = localStorage.getItem("customer_id");

  useEffect(() => {
    const fetchOrderData = async () => {
      if (!customerId) return;

      try {
        const response = await fetch('http://127.0.0.1:8000/customer-my-order', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ customer_id: customerId }),
        });

        const data = await response.json();
        console.log("Fetched order data:", data);

        if (data.status_code === 200) {
          setOrderDetails(data.payments || []);
        } else {
          console.error(data.error || 'Something went wrong.');
        }
      } catch (error) {
        console.error('Fetch error:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchOrderData();
  }, [customerId]);

  if (loading) {
    return <div className="order-loader">Loading...</div>;
  }

  if (!orderDetails.length) {
    return (
      <div className="order-loader">
        <p>No orders found for this customer.</p>
      </div>
    );
  }

  return (
      <div className="order-box">
        <h4 className="main-heading">Order ID: {order.product_order_id}</h4>

        {/* Product Section */}
        <div className="order-details-container">
  {/* Left side: Product + Payment */}
  <div className="left-side">
    <div className="product-section">
      {order.order_products?.length > 0 &&
        order.order_products.map((product, idx) => (
          <div key={idx} className="product-item">
            <div className="order-item-wrapper">
              <div className="product-info-box">
                <p className='product-name-details'><strong>Product Name:</strong> {product.product_name}</p>
                <p><strong>Price:</strong> ₹{product.price}</p>
              </div>
              <img
                src={`http://127.0.0.1:8000/${product.product_image}`}
                alt={product.product_name}
                className="product-image"
              />
            </div>
          </div>
        ))}
    </div>

    <div className="payment-box">
      <h3>Payment Details</h3>
      <p><strong>Mode:</strong> {order.payment_mode}</p>
      <p><strong>Total Quantity:</strong> {order.total_quantity}</p>
      <p><strong>Total Amount:</strong> ₹{order.total_amount}</p>
      <p><strong>Date:</strong> {order.payment_date}</p>
    </div>
  </div>

  {/* Right side: Address */}
  <div className="right-side">
    {order.customer_address?.length > 0 && (
      <div className="shipping-address-box">
        <h3>Shipping Address</h3>
        <p><strong>{order.customer_name}</strong></p>
        <p>{order.customer_address[0].street}, {order.customer_address[0].landmark}, {order.customer_address[0].village}</p>
        <p>{order.customer_address[0].mandal}, {order.customer_address[0].postoffice}, {order.customer_address[0].district}</p>
        <p>{order.customer_address[0].state} - {order.customer_address[0].pincode}</p>
        <p>{order.customer_address[0].country}</p>
        <p><strong>Phone:</strong> {order.customer_address[0].mobile_number}</p>
      </div>
    )}
  </div>
</div>

    </div>
  );
};

export default CustomerMyOrderDetails;
